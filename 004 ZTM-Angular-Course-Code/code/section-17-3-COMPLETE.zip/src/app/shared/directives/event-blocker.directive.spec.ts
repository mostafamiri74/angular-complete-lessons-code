import { EventBlockerDirective } from './event-blocker.directive';

describe('EventBlockerDirective', () => {
  it('should create an instance', () => {
    const directive = new EventBlockerDirective();
    expect(directive).toBeTruthy();
  });
});
